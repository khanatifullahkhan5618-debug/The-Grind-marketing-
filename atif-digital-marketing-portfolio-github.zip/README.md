# ATIF ULLAH KHAN — Digital Marketing Portfolio

## GitHub Pages setup

1. Create a new GitHub repository.
2. Upload **all files and folders** from this project, keeping `assets/atif-profile.jpg` in the `assets` folder.
3. Go to **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select your main branch and `/ (root)`, then Save.
6. GitHub will give you the live website URL.

## Files

- `index.html` — website structure
- `style.css` — design, responsive layout and animations
- `script.js` — 3D particle background, menu, reveal animations and WhatsApp form
- `assets/atif-profile.jpg` — your uploaded profile photo

## Important

The portfolio deliberately does not invent client names, testimonials, revenue, ROAS or campaign results. Replace the three project placeholders with your real projects/results when you have them.

The contact form does not require a server. It opens WhatsApp with the visitor's message.
