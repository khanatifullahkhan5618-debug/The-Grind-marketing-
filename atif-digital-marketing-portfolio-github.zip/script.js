const loader=document.getElementById("loader");
window.addEventListener("load",()=>setTimeout(()=>loader.style.opacity="0",400));
setTimeout(()=>{loader.style.display="none"},1200);

const menu=document.querySelector(".menu");
const nav=document.getElementById("navLinks");
menu?.addEventListener("click",()=>nav.classList.toggle("open"));
nav?.querySelectorAll("a").forEach(a=>a.addEventListener("click",()=>nav.classList.remove("open")));

const observer=new IntersectionObserver(entries=>{
  entries.forEach(e=>{if(e.isIntersecting)e.target.classList.add("show")});
},{threshold:.12});
document.querySelectorAll(".reveal").forEach(el=>observer.observe(el));

document.getElementById("year").textContent=new Date().getFullYear();

document.getElementById("contactForm").addEventListener("submit",e=>{
  e.preventDefault();
  const data=new FormData(e.currentTarget);
  const name=data.get("name"), email=data.get("email"), message=data.get("message");
  const text=`Hi Atif, I want to discuss a digital marketing project.%0A%0AName: ${encodeURIComponent(name)}%0AEmail: ${encodeURIComponent(email)}%0AProject: ${encodeURIComponent(message)}`;
  window.open(`https://wa.me/923112692744?text=${text}`,"_blank");
});

/* Lightweight 3D particle field — no external library required. */
const canvas=document.getElementById("webgl"), ctx=canvas.getContext("2d");
let W,H,dpr,points=[];
function resize(){
  dpr=Math.min(devicePixelRatio||1,2); W=innerWidth; H=innerHeight;
  canvas.width=W*dpr; canvas.height=H*dpr; canvas.style.width=W+"px"; canvas.style.height=H+"px";
  ctx.setTransform(dpr,0,0,dpr,0,0);
  points=Array.from({length:Math.min(150,Math.floor(W/8))},()=>({
    x:Math.random()*W,y:Math.random()*H,z:Math.random()*1+.15,
    vx:(Math.random()-.5)*.12,vy:(Math.random()-.5)*.12
  }));
}
resize(); addEventListener("resize",resize);
let mx=0,my=0; addEventListener("pointermove",e=>{mx=(e.clientX/W-.5)*10;my=(e.clientY/H-.5)*10});
function draw(){
  ctx.clearRect(0,0,W,H);
  const grad=ctx.createRadialGradient(W*.65,H*.38,0,W*.65,H*.38,Math.min(W,H)*.65);
  grad.addColorStop(0,"rgba(35,120,190,.12)");grad.addColorStop(1,"rgba(0,0,0,0)");
  ctx.fillStyle=grad;ctx.fillRect(0,0,W,H);
  for(let i=0;i<points.length;i++){
    const p=points[i];p.x+=p.vx;p.y+=p.vy;
    if(p.x<0)p.x=W;if(p.x>W)p.x=0;if(p.y<0)p.y=H;if(p.y>H)p.y=0;
    const x=p.x+mx*p.z,y=p.y+my*p.z;
    ctx.fillStyle=`rgba(100,205,255,${.12+p.z*.28})`;ctx.beginPath();ctx.arc(x,y,1+p.z*1.2,0,Math.PI*2);ctx.fill();
    for(let j=i+1;j<points.length;j++){
      const q=points[j],qx=q.x+mx*q.z,qy=q.y+my*q.z,dx=x-qx,dy=y-qy,dist=Math.hypot(dx,dy);
      if(dist<100){ctx.strokeStyle=`rgba(70,170,220,${(1-dist/100)*.055})`;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,y);ctx.lineTo(qx,qy);ctx.stroke();}
    }
  }
  requestAnimationFrame(draw);
}
draw();
